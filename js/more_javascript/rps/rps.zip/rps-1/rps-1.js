/*
	1. create 3 variables that are all equal to 0
	2. append them to the wins, losses, and ties in the html
*/