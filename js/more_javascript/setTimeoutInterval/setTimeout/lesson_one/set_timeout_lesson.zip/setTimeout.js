$(document).ready(function(){

	//after 5 seconds of document loading
	setTimeout(function(){
		console.log("this happens after 5 seconds");
	}, 5000);

	//after 10 seconds of document loading
	setTimeout(function(){
		console.log("this happens after 10 seconds");
	}, 10000);

});