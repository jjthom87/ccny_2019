$(document).ready(function(){

	// hide the button

	// After 3 seconds, show the button

	// When the button is clicked
	// After 6 seconds, add a p tag to the div

});