$(document).ready(function(){

	var beatles = [
		{
			album: "Help",
			year: 1965,
			img: "help"
		},
		{
			album: "Rubber Soul",
			year: 1966,
			img: "rubber_soul"
		},
		{
			album: "Sgt Peppers Lonely Hearts Club Band",
			year: 1967,
			img: "peppers"
		}
	];

	//Display the albums in order of year after 6 seconds each
	//remove the welcoming p tag right before the first album shows
	//Make sure to remove the album after 6 seconds and then display the next album
	//At the end of the slideshow, empty and then thank the viewers for watching

});