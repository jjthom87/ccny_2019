$(document).ready(function(){

	var num = 100
	var interval;

	// append number to appropriate p tag

	//when start is clicked, decrease number each second
	//remember to use interval variable across both on click functions

	//when pause button is clicked, pause the time

	//when stop button is clicked, reset the timer back 100
});