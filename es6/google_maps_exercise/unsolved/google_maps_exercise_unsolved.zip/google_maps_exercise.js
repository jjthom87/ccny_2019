$(document).ready(function(){

/*

Use the weathermap api and google map api to generate the map and weather for 
a city with one call, using the input of the city to generate the results

*/

});