$(document).ready(function(){
	/*
		1. Use the search box and the giphy api
		2. When you click search, the modal pops up with one random giphy from the search
		3. When you click on the next button, a new giphy shows
		4. Only one giphy should be in the modal at a time
	*/
});