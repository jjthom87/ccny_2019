/* https://developers.google.com/maps/documentation/javascript/examples/ */
$(document).ready(function(){

	var host = 'data.usajobs.gov';
    var userAgent = 'rodricksnyc@gmail.com';
    var authKey = 'ZVRFnMsfJGJ+6jvGyznqQPRyhF9n5h9jSS259lekdgU=';
	var apiUrl = "https://data.usajobs.gov/api/Search?Organization=AF&PositionTitle=Social%20Services"
	var latsAndLongs = [];
	$.ajax({
		type: 'GET',
		url: apiUrl,
        headers: {
          "Host": host,
          "User-Agent": userAgent,
          "Authorization-Key": authKey
        },
      	success: function(response){
      		console.log(response)
      		var results = response.SearchResult.SearchResultItems;
      		for(var i = 0; i < results.length; i++){
      			latsAndLongs.push({lat: results[i].MatchedObjectDescriptor.PositionLocation[0].Latitude, lng: results[i].MatchedObjectDescriptor.PositionLocation[0].Longitude})
      		}
      	}
    });

	var coordinates = [{lat: 40.8116, lng: -73.9465},{lat: 41.8116, lng: -74.9465}];

	//the center is the coordinates for harlem, a center is needed here
  	setTimeout(function(){
	    var map = new google.maps.Map(document.getElementById('map'), {
	      center: coordinates[0],
	      zoom: 3
	    });

	    var marker;
	    for(var i = 0; i < latsAndLongs.length; i++){
		    marker = new google.maps.Marker({
		      position: latsAndLongs[i],
		      map: map
		    });
	    }
  	},3000)

})