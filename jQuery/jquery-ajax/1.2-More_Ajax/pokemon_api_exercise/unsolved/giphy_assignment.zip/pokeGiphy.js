/*

Query the Giphy API
Display Results in html format
Set events on the results
api: http://api.giphy.com/v1/gifs/search?q=<right here>&api_key=dc6zaTOxFJmzC&limit=10

*/

$(document).ready(function(){
	
	

});